package main

import (
	"fmt"
	"sort"
)

type member struct {
	id    string
	money int
}

func main() {
	m := member{}
	inputMember()
}

func inputMember(m *member) {
	fmt.Print("Input Member ID : ")
	fmt.Scan(&(m.id))
	if (m.id) == "" {
		fmt.Println("Mohon maaf, toko Enigma Jaya hanya berlaku untuk member saja")
	} else {
		fmt.Print("Money : ")
		fmt.Scan(&(m.money))
		if (m.money) < 50000 {
			fmt.Println("Mohon maaf, uang tidak cukup")
		} else {
			belanja()
		}
	}
}

func belanja() {
	barang := map[string]int{
		"Sepatu Ceebok":    1500000,
		"Baju Zoro":        500000,
		"Baju H&N":         250000,
		"Sweater Uniklooh": 175000,
		"Casing Handphone": 50000,
	}
	sortByPrice := make([]string, 0, len(barang))
	for k := range barang {
		sortByPrice = append(sortByPrice, k)
	}
	sort.Strings(sortByPrice)

}
