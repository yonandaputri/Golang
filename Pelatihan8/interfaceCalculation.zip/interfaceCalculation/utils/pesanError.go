package utils

type AngkaNegatifError struct {
	PesanMasalah string
}

func (err AngkaNegatifError) Error() string {
	return err.PesanMasalah
}
