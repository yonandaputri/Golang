package main

import (
	"Pelatihan8/interfaceCalculation/pengurangan"
	"fmt"
)

func main() {
	var input1, input2 int
	fmt.Print("Input angka 1 : ")
	fmt.Scan(&input1)
	fmt.Print("Input angka 2 : ")
	fmt.Scan(&input2)
	substraction := pengurangan.Pengurangan{input1, input2}
	printHasilHitung(substraction)
}

func printHasilHitung(c pengurangan.Calculator) {
	hasil, pesanError := c.GetCalculation()
	if pesanError == nil {
		fmt.Println("Hasil Pengurangan : ", hasil)
	} else {
		fmt.Println(pesanError.Error())
	}

}
