package pengurangan

type Calculator interface {
	GetCalculation() (int, error)
}
